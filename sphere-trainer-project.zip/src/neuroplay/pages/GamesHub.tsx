import { useNeuroPlayStore } from '../store/useNeuroPlayStore';
import { GAME_META, DOMAIN_LABEL, type GameId } from '../types';
import { DifficultyDots } from '../components/GameFrame';

const GAME_IDS = Object.keys(GAME_META) as GameId[];

export function GamesHub() {
  const openGame = useNeuroPlayStore((s) => s.openGame);
  const difficultyByGame = useNeuroPlayStore((s) => s.difficultyByGame);

  return (
    <div className="p-6 md:p-10 max-w-5xl mx-auto w-full">
      <h1 className="text-3xl font-bold text-slate-50 mb-2">Games</h1>
      <p className="text-slate-400 text-lg mb-8">Each game targets a specific cognitive domain and adapts to your performance.</p>
      <div className="grid sm:grid-cols-2 gap-4">
        {GAME_IDS.map((id) => {
          const meta = GAME_META[id];
          return (
            <button key={id} className="np-game-card" onClick={() => openGame(id)}>
              <div className="flex items-start justify-between mb-2">
                <span className="text-xs uppercase tracking-widest text-teal-400 font-semibold">
                  {DOMAIN_LABEL[meta.domain]}
                </span>
                <DifficultyDots level={difficultyByGame[id]} />
              </div>
              <p className="text-xl font-bold text-slate-50 mb-1">{meta.name}</p>
              <p className="text-sm text-slate-400">{meta.description}</p>
            </button>
          );
        })}
      </div>
    </div>
  );
}

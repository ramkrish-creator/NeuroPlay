const STAGES = [
  'Performance Data',
  'Cognitive State Estimation',
  'Fatigue / Trend Analysis',
  'Adaptive Decision',
  'Next Game Difficulty',
];

/** Visualises how the Adaptive Prototype Engine turns raw trial data into
 *  a difficulty decision — the core research contribution this platform
 *  demonstrates. */
export function AdaptivePipeline() {
  return (
    <div className="np-card p-6">
      <p className="np-section-title mb-4">How Adaptation Works</p>
      <div className="flex flex-col md:flex-row items-stretch md:items-center gap-2">
        {STAGES.map((stage, i) => (
          <div key={stage} className="flex items-center gap-2 flex-1">
            <div className="np-pipeline-stage">{stage}</div>
            {i < STAGES.length - 1 && <span className="np-pipeline-arrow">→</span>}
          </div>
        ))}
      </div>
      <p className="text-xs text-slate-500 mt-4 leading-relaxed">
        Adaptive Prototype Engine — a transparent, explainable rule system (rolling
        accuracy, reaction-time drift, and error streaks). Built with the same
        interfaces a future ML/RL model could use instead.
      </p>
    </div>
  );
}
